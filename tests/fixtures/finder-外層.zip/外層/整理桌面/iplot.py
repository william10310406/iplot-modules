"""把桌面上的截圖收起來。"""
ICON = "🧹"
def run(app):
    app.log("收好了")
